'use client'

import * as React from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'

type ApptRow = {
  id: string
  starts_at: string
  ends_at: string
  status: 'scheduled'|'completed'|'cancelled'
  reason: string | null
  notes: string | null
  patients?: { first_name: string; last_name: string; phone?: string | null } | null
}

// --- Helpers ----------------------------------------------------------------

// Convierte fecha+hora local a un instante UTC (Z)
function withLocalOffset(dateStr: string, timeStr: string) {
  const [y, m, d] = dateStr.split('-').map(Number)
  const [hh, mm] = timeStr.split(':').map(Number)
  const dt = new Date(y, m - 1, d, hh, mm, 0)
  return dt.toISOString()
}

// Normaliza teléfono a E.164 (sencillo) con CC por default (52=MX)
function formatE164(rawPhone: string | null | undefined, defaultCc: string = '52') {
  const digits = (rawPhone ?? '').replace(/[^\d]/g, '')
  if (!digits) return ''
  if (digits.startsWith(defaultCc)) return digits
  if (digits.startsWith('00' + defaultCc)) return digits.slice(2)
  if (digits.startsWith('0' + defaultCc)) return digits.slice(1)
  if (digits.startsWith('1') && defaultCc === '1') return digits  // US/CA
  return defaultCc + digits
}

// Abre WhatsApp inmediatamente (compatible iOS/PC) y registra recordatorio en BD (best-effort)
async function sendManualWhatsAppReminder(opts: {
  appointmentId: string
  patientName: string
  patientPhone: string
  startsAt: string
  clinicName?: string | null
}) {
  const cc = (process.env.NEXT_PUBLIC_COUNTRY_PREFIX || process.env.COUNTRY_PREFIX || '52') as string
  const phoneE164 = formatE164(opts.patientPhone, String(cc))
  if (!phoneE164) throw new Error('Teléfono inválido')

  const when = new Date(opts.startsAt).toLocaleString()
  const msg = 
    `Hola ${opts.patientName},\n\n` +
    `Le recordamos su cita el ${when}.\n` +
    `Si necesita reprogramar, por favor avísenos.\n\n` +
    `${opts.clinicName || 'Clínica Odontológica Integral'}`

  // 1) Abrir wa.me inmediatamente para evitar bloqueadores
  const waUrl = `https://wa.me/${phoneE164}?text=${encodeURIComponent(msg)}`
  const a = document.createElement('a')
  a.href = waUrl; a.target = '_blank'; a.rel = 'noopener noreferrer'
  document.body.appendChild(a); a.click(); a.remove()

  // 2) Intentar Cloud API en paralelo (no bloquea UI)
  try {
    fetch('/api/whatsapp/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phoneE164, text: msg }),
    }).catch(()=>{})
  } catch {}

  // 3) Registrar log (best-effort)
  try {
    await supabase.from('reminders').insert({
      appointment_id: opts.appointmentId,
      kind: 'manual',
      status: 'ok',
    })
  } catch {}

  return { ok: true as const, via: 'wa.me' as const }
}

// --- Page Component ----------------------------------------------------------

export default function AppointmentView() {
  const { id } = useParams<{ id: string }>()
  const router = useRouter()

  const [row, setRow] = React.useState<ApptRow | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [err, setErr] = React.useState<string | null>(null)

  // Local editable fields
  const [date, setDate] = React.useState<string>('')
  const [start, setStart] = React.useState<string>('10:00')
  const [end, setEnd] = React.useState<string>('11:00')
  const [reason, setReason] = React.useState<string>('')
  const [notes, setNotes] = React.useState<string>('')
  const [saving, setSaving] = React.useState(false)

  React.useEffect(() => {
    (async () => {
      setLoading(true)
      const { data, error } = await supabase
        .from('appointments')
        .select('id, starts_at, ends_at, status, reason, notes, patients(first_name,last_name,phone)')
        .eq('id', id)
        .single()
      setLoading(false)
      if (error) { setErr(error.message); return }
      setRow(data as any)

      // seed local fields
      const s = new Date((data as any).starts_at)
      const e = new Date((data as any).ends_at)
      const pad = (n:number)=> String(n).padStart(2,'0')
      setDate(`${s.getFullYear()}-${pad(s.getMonth()+1)}-${pad(s.getDate())}`)
      setStart(`${pad(s.getHours())}:${pad(s.getMinutes())}`)
      setEnd(`${pad(e.getHours())}:${pad(e.getMinutes())}`)
      setReason((data as any).reason ?? '')
      setNotes((data as any).notes ?? '')
    })()
  }, [id])

  async function onSave(e: React.FormEvent) {
    e.preventDefault()
    if (!row) return
    setSaving(true)
    const starts_at = withLocalOffset(date, start)
    const ends_at   = withLocalOffset(date, end)
    const { error } = await supabase.from('appointments')
      .update({ starts_at, ends_at, reason, notes })
      .eq('id', row.id)
    setSaving(false)
    if (error) { alert(error.message); return }
    router.refresh()
  }

  async function setStatus(next: 'scheduled'|'completed'|'cancelled') {
    if (!row) return
    const { error } = await supabase.from('appointments').update({ status: next }).eq('id', row.id)
    if (error) return alert(error.message)
    setRow({ ...(row as any), status: next } as ApptRow)
  }

  if (loading) return <div className="p-4">Cargando…</div>
  if (err) return <div className="p-4 text-red-700">{err}</div>
  if (!row) return <div className="p-4">No encontrada</div>

  const patientName = row.patients ? `${row.patients.last_name}, ${row.patients.first_name}` : '—'

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Cita</h1>
        <div className="flex gap-2">
          <button
            className="px-3 py-2 rounded bg-indigo-600 text-white"
            onClick={() => {
              if (!row) return
              const phone = row.patients?.phone ?? ''
              sendManualWhatsAppReminder({
                appointmentId: row.id,
                patientName: patientName,
                patientPhone: phone,
                startsAt: row.starts_at,
                clinicName: 'Clínica Odontológica Integral',
              }).catch(err => console.error(err))
            }}
          >
            Enviar recordatorio (WA)
          </button>
          <Link className="px-3 py-2 rounded border" href="/citas">Volver</Link>
        </div>
      </div>

      <div className="text-sm text-neutral-700">
        <div><b>Paciente:</b> {patientName}</div>
        <div><b>Estatus:</b> {row.status}</div>
      </div>

      <form onSubmit={onSave} className="card p-4 space-y-3">
        <div className="grid md:grid-cols-3 gap-3">
          <div>
            <label className="block text-sm mb-1">Fecha</label>
            <input type="date" className="input w-full" value={date} onChange={e=>setDate(e.target.value)} />
          </div>
          <div>
            <label className="block text-sm mb-1">Hora inicio</label>
            <input type="time" className="input w-full" value={start} onChange={e=>setStart(e.target.value)} />
          </div>
          <div>
            <label className="block text-sm mb-1">Hora fin</label>
            <input type="time" className="input w-full" value={end} onChange={e=>setEnd(e.target.value)} />
          </div>
        </div>

        <div>
          <label className="block text-sm mb-1">Motivo</label>
          <input className="input w-full" value={reason} onChange={e=>setReason(e.target.value)} placeholder="Varios" />
        </div>
        <div>
          <label className="block text-sm mb-1">Notas</label>
          <textarea className="input w-full" rows={4} value={notes} onChange={e=>setNotes(e.target.value)} />
        </div>

        <div className="flex flex-wrap gap-2">
          <button className="btn" disabled={saving}>{saving ? 'Guardando…' : 'Guardar'}</button>
          <button type="button" className="px-3 py-2 rounded bg-sky-600 text-white" onClick={()=>setStatus('scheduled')}>Programada</button>
          <button type="button" className="px-3 py-2 rounded bg-emerald-600 text-white" onClick={()=>setStatus('completed')}>Completada</button>
          <button type="button" className="px-3 py-2 rounded bg-rose-600 text-white" onClick={()=>setStatus('cancelled')}>Cancelada</button>
        </div>
      </form>
    </div>
  )
}
