// Auto-added to prevent Vercel/tsc from failing when html2canvas is referenced in optional/unused files.
// If you actually use html2canvas at runtime, install it: npm i html2canvas

declare module 'html2canvas' {
  const html2canvas: any
  export default html2canvas
}
