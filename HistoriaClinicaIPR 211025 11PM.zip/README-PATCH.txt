Parche exacto 20250909-0440. Reemplaza páginas integradas y agrega módulos kit.
